let todaysTotalTimeInActiveDomain = 0;
let activeTabId = null;
const trackedTabIds = new Set();
let timerInterval = null;

const SAVE_INTERVAL_SECONDS = Constants.SAVE_INTERVAL_SECONDS;
let tabLastActivity = {};
let trackedTabDomain = null;
const INACTIVITY_THRESHOLD_MS = Constants.INACTIVITY_THRESHOLD_MS;
const ACTIVITY_CHECK_INTERVAL_MS = Constants.ACTIVITY_CHECK_INTERVAL_MS;

let currentDateStr = Utils.getLocalDateStr(); 
let timeHistory = {};
let dayResetTime = 0; // Hour when day resets
let isSaving = false; // Lock to prevent race conditions during simultaneous saves

// Nudge and reminder system state
let interventionState = {
    lastNudgeTime: {},         // domain -> timestamp (φ-nudges)
    lastReminderTime: {},      // domain -> timestamp (reminders)
    snoozedUntil: {}           // domain -> timestamp or 'tomorrow'
};

// Use shared utility function
function getLocalDateStr() {
    return Utils.getLocalDateStr(dayResetTime);
}

// Use shared utility function
function extractDomain(url) {
    return Utils.extractDomain(url);
}

function migrateDataIfNeeded(oldTimeHistory) {
    // Check if data is in old format (values are numbers instead of objects)
    const dates = Object.keys(oldTimeHistory);
    if (dates.length === 0) return oldTimeHistory;

    const firstDate = dates[0];
    if (typeof oldTimeHistory[firstDate] === "number") {
        console.log("Migrating old YouTube-only data to new multi-site format");

        // Convert: "2025-04-26": 12145 -> "2025-04-26": {"youtube.com": 12145}
        const migratedHistory = {};
        for (const [date, seconds] of Object.entries(oldTimeHistory)) {
            migratedHistory[date] = {
                "youtube.com": seconds,
            };
        }

        console.log(`Migrated ${dates.length} days of data from old format`);
        return migratedHistory;
    }

    // Data is already in new format
    console.log("Data already in new multi-site format");
    return oldTimeHistory;
}

function initDefaultTimeData() {
    todaysTotalTimeInActiveDomain = 0;
    timeHistory = {};
    console.log("Initialized with default values");
}

async function saveTimeData() {
    if (isSaving) {
        console.log('Save already in progress, skipping...');
        return;
    }
    
    isSaving = true;
    console.log(`saveTimeData() ${currentDateStr}: ${todaysTotalTimeInActiveDomain} seconds`);
    
    try {
        if (!timeHistory[currentDateStr]) {
            timeHistory[currentDateStr] = {};
        }

        // timeHistory[currentDateStr]["youtube.com"] = todaysTotalTimeInActiveDomain;
        if (trackedTabDomain) {
            timeHistory[currentDateStr][trackedTabDomain] = todaysTotalTimeInActiveDomain;
        }

        const storageData = {
            lastDate: currentDateStr,
            timeHistory: timeHistory,
            version: 1,
        };

        await browser.storage.local.set({
            trackedTime: storageData,
        });
        console.log("Time data successfully saved with history.");
    } catch (error) {
        console.error("Error saving time data to storage:", error);
    } finally {
        isSaving = false;
    }
}

async function loadTimeData() {
    try {
        const storedData = await browser.storage.local.get("trackedTime");
        const trackedTime = storedData.trackedTime;

        if (!trackedTime || !trackedTime.lastDate || !trackedTime.timeHistory) {
            initDefaultTimeData();
            return;
        }

        timeHistory = migrateDataIfNeeded(trackedTime.timeHistory);

        if (currentDateStr !== trackedTime.lastDate) {
            console.log(
                `New day detected (Last: ${trackedTime.lastDate}, Now: ${currentDateStr})`
            );
            todaysTotalTimeInActiveDomain = 0;
        } else {
            const todaysData = timeHistory[currentDateStr] || {};
            // todaysTotalTimeInActiveDomain = todaysData["youtube.com"] || 0;
            todaysTotalTimeInActiveDomain = trackedTabDomain ? (todaysData[trackedTabDomain] || 0) : 0;
        }

        console.log(
            `Loaded data for ${currentDateStr}, time: ${todaysTotalTimeInActiveDomain}`
        );
    } catch (error) {
        console.error("Error loading time data:", error);
        initDefaultTimeData();
    }
}

function incrementTimer() {
    todaysTotalTimeInActiveDomain++;
    const newDateStr = getLocalDateStr();
    if (newDateStr !== currentDateStr) {
        saveTimeData();
        currentDateStr = newDateStr;
        todaysTotalTimeInActiveDomain = 0;
        // Reset intervention state for new day
        interventionState = {
            lastNudgeTime: {},
            lastReminderTime: {},
            snoozedUntil: {}
        };
        console.log("New day, reset timer.");
    }
    updateTimerDisplay(todaysTotalTimeInActiveDomain);

    if (todaysTotalTimeInActiveDomain % SAVE_INTERVAL_SECONDS === 0) {
        saveTimeData();
    }
    
    checkForInterventions();
}

function startTimer() {
    if (timerInterval) return;

    timerInterval = setInterval(incrementTimer, 1000);
    console.log("Timer started.");
}

function stopTimer() {
    if (!timerInterval) return;

    clearInterval(timerInterval);
    timerInterval = null;
    saveTimeData();
}

function updateTimerDisplay(updatedTime) {
    const message = { type: "TIME_UPDATE", time: updatedTime };
    trackedTabIds.forEach((tabId) => {
        browser.tabs.sendMessage(tabId, message).catch((error) => {
            console.warn(`Failed to send TIME_UPDATE to tab ${tabId}. Removing from tracking.`);
            trackedTabIds.delete(tabId); 
            delete tabLastActivity[tabId]; 
        });
    });
}

async function updateTimingState(tabId) {
    try {
        const activeTab = await browser.tabs.get(tabId);
        if (!activeTab || !activeTab.url) {
            console.log(`Tab ${tabId} was closed or has no URL`);
            stopTimer();
            return;
        }

        handleDomainSwitch(activeTab.url);
        handleTimerState(activeTab, tabId);
        
    } catch (error) {
        console.error(`Error in updateTimingState for tab ${tabId}:`, error);
        stopTimer();
    }
}

function handleDomainSwitch(url) {
    const domain = extractDomain(url);
    if (domain === trackedTabDomain) { return; }

    if (trackedTabDomain) {
        saveTimeData();
    }

    trackedTabDomain = domain;
    
    if (!trackedTabDomain) {
        Utils.log(`Switched to non-trackable URL: ${url}`);
        todaysTotalTimeInActiveDomain = 0;
        updateTimerDisplay(0);
        return;
    }

    const todayData = timeHistory[currentDateStr] || {};
    todaysTotalTimeInActiveDomain = todayData[trackedTabDomain] || 0;
    console.log(`Switched to domain: ${trackedTabDomain}, time: ${todaysTotalTimeInActiveDomain}`);
    updateTimerDisplay(todaysTotalTimeInActiveDomain);
}

function handleTimerState(activeTab, tabId) {
    const isWebUrl = activeTab.url.startsWith('http://') || activeTab.url.startsWith('https://');
    if (!isWebUrl) {
        stopTimer();
        return;
    }

    const lastActivity = tabLastActivity[tabId] || 0;
    const isUserActive = (Date.now() - lastActivity) < INACTIVITY_THRESHOLD_MS;
    
    if (activeTab.audible || isUserActive) {
        startTimer();
    } else {
        stopTimer();
    }
}

function handleTabActivated(activeInfo) {
    console.log(`handleTabActivated called for tab ${activeInfo.tabId}`);
    activeTabId = activeInfo.tabId;
    updateTimingState(activeTabId);
}

function handleTabUpdated(tabId, changeInfo, tab) {
    if (changeInfo.url !== undefined) {
        const domain = extractDomain(changeInfo.url);
        if (domain) {
            trackedTabIds.add(tabId);
            console.log(`Added tab ${tabId} to tracked tabs`);
        } else {
            trackedTabIds.delete(tabId);
            delete tabLastActivity[tabId]; 
            console.log(`Removed tab ${tabId} from tracked tabs`);
        }
    }
    const hasRelevantChanges = changeInfo.url !== undefined || changeInfo.audible !== undefined;
    if (tabId === activeTabId && hasRelevantChanges) {
        updateTimingState(tabId);
    }
}

function handleTabRemoved(tabId, removeInfo) {
    if (tabId === activeTabId) {
        stopTimer();
        activeTabId = null;
    }
    trackedTabIds.delete(tabId);
    delete tabLastActivity[tabId];
}

function handleMessageReceived(message, sender, sendResponse) {
    console.log(`handleMessage()`, message, sender);
    if (message.type === "CONTENT_SCRIPT_READY" && sender.tab) {
        trackedTabIds.add(sender.tab.id);
        updateTimerDisplay(todaysTotalTimeInActiveDomain);
    }
    if (message.type === "USER_ACTIVE" && sender.tab) {
        tabLastActivity[sender.tab.id] = Date.now();
    }
    if (message.type === "SNOOZE_REMINDERS" && sender.tab) {
        const domain = extractDomain(sender.tab.url);
        if (domain) {
            interventionState.snoozedUntil[domain] = message.duration;
            console.log(`Snoozed reminders for ${domain} until`, message.duration);
        }
    }
    if (message.type === "SETTINGS_UPDATED") {
        // Reload day reset time when settings change
        browser.storage.local.get('webTimeSettings').then(data => {
            const settings = data.webTimeSettings || { global: {} };
            const newResetTime = settings.global?.dayResetTime || 0;
            if (newResetTime !== dayResetTime) {
                dayResetTime = newResetTime;
                console.log(`Day reset time updated to: ${dayResetTime}:00`);
                // Recalculate current date with new reset time
                const newDateStr = getLocalDateStr();
                if (newDateStr !== currentDateStr) {
                    // Date changed due to reset time change, trigger rollover
                    saveTimeData();
                    currentDateStr = newDateStr;
                    const todayData = timeHistory[currentDateStr] || {};
                    todaysTotalTimeInActiveDomain = trackedTabDomain ? (todayData[trackedTabDomain] || 0) : 0;
                    updateTimerDisplay(todaysTotalTimeInActiveDomain);
                    console.log(`Date changed to ${currentDateStr} due to reset time change`);
                }
            }
        });
    }
}

function importData(file) {
    const reader = new FileReader();
    reader.onload = (event) => {
        const data = JSON.parse(event.target.result);
        browser.storage.local.set(data);
    };
    reader.readAsText(file);
}

function exportData() {
    browser.storage.local.get("trackedTime").then((data) => {
        const blob = new Blob([JSON.stringify(data)], {
            type: "application/json",
        });
        const url = URL.createObjectURL(blob);

        browser.downloads.download({
            url: url,
            filename: "webtime-data.json",
            saveAs: true,
        });
    });
}

async function checkForInterventions() {
    if (!trackedTabDomain || !activeTabId) return;
    
    const isCurrentlyActive = await checkAndClearSnooze();
    if (!isCurrentlyActive) return;
    
    const settings = await loadInterventionSettings();
    if (!settings) return;
    
    // φ-nudges are automatic when reminders are enabled
    checkPhiBasedNudges(settings);
    checkTier2Reminders(settings);
}

async function checkAndClearSnooze() {
    const snoozeUntil = interventionState.snoozedUntil[trackedTabDomain];
    if (!snoozeUntil) return true;
    
    const isSnoozedUntilTomorrow = snoozeUntil === 'tomorrow';
    if (isSnoozedUntilTomorrow) return false;
    
    const isStillSnoozed = Date.now() < snoozeUntil;
    if (isStillSnoozed) return false;
    
    // Snooze expired, clear it
    delete interventionState.snoozedUntil[trackedTabDomain];
    return true;
}

async function loadInterventionSettings() {
    const data = await browser.storage.local.get('webTimeSettings');
    const settings = data.webTimeSettings || { global: {}, domains: {} };
    const global = settings.global || {};
    const domainSettings = settings.domains?.[trackedTabDomain] || {};
    
    const reminderEnabled = domainSettings.reminderEnabled || false;
    
    if (!reminderEnabled) return null;
    
    return {
        global,
        domainSettings,
        reminderEnabled,
        reminderThreshold: domainSettings.reminderThreshold * 60, // convert to seconds
        reminderInterval: domainSettings.reminderInterval,
        timeInSeconds: todaysTotalTimeInActiveDomain
    };
}

/**
 * Check if it's time to show a φ-based nudge
 * Uses exponential decay spacing that accelerates as time passes
 */
function checkPhiBasedNudges(settings) {
    const { reminderThreshold, reminderInterval, timeInSeconds, domainSettings } = settings;
    
    // Don't nudge after hitting reminder threshold
    if (timeInSeconds >= reminderThreshold) return;
    
    const timeLimitMinutes = reminderThreshold / 60;
    const reminderIntervalMinutes = reminderInterval;
    
    // Get user's nudge count preference (undefined = use recommended)
    const userNudgeCount = domainSettings.nudgeCount;
    
    // Calculate nudge times - use user count if set, otherwise calculate recommended
    const nudgeTimes = Utils.calculatePhiNudgeTimes(timeLimitMinutes, reminderIntervalMinutes, userNudgeCount);
    
    // Check if current time matches any nudge time
    for (const nudgeTime of nudgeTimes) {
        if (timeInSeconds === nudgeTime) {
            const lastNudge = interventionState.lastNudgeTime[trackedTabDomain] || -1;
            
            // Prevent duplicate nudges at same time
            if (timeInSeconds !== lastNudge) {
                sendNudge();
                interventionState.lastNudgeTime[trackedTabDomain] = timeInSeconds;
                console.log(`φ-nudge triggered at ${Math.round(timeInSeconds/60)}min`);
                break;
            }
        }
    }
}

function checkTier2Reminders(settings) {
    const { reminderEnabled, reminderThreshold, reminderInterval, timeInSeconds, global } = settings;
    
    if (!reminderEnabled) return;
    
    const hasReachedReminderThreshold = timeInSeconds >= reminderThreshold;
    if (!hasReachedReminderThreshold) return;
    
    const timeOverThreshold = timeInSeconds - reminderThreshold;
    const reminderIntervalSeconds = reminderInterval * 60;
    const isOnReminderInterval = timeOverThreshold % reminderIntervalSeconds === 0;
    if (!isOnReminderInterval) return;
    
    const lastReminder = interventionState.lastReminderTime[trackedTabDomain] || -1;
    const alreadyRemindedAtThisTime = timeInSeconds === lastReminder;
    if (alreadyRemindedAtThisTime) return;
    
    showReminder(global.customMessage);
    interventionState.lastReminderTime[trackedTabDomain] = timeInSeconds;
}

function sendNudge() {
    if (!activeTabId) return;
    
    browser.tabs.sendMessage(activeTabId, {
        type: 'NUDGE'
    }).catch(err => console.warn('Failed to send nudge:', err));
}

function showReminder(customMessage) {
    if (!activeTabId) return;
    
    const totalTime = Utils.formatTimeWithSeconds(todaysTotalTimeInActiveDomain);
    
    browser.tabs.sendMessage(activeTabId, {
        type: 'SHOW_REMINDER',
        customMessage: customMessage,
        totalTime: totalTime,
        duration: Constants.OVERLAY_DURATIONS.REMINDER_DISPLAY_MS
    }).catch(err => console.warn('Failed to show reminder:', err));
}

async function init() {
    browser.tabs.onActivated.addListener(handleTabActivated);
    browser.tabs.onUpdated.addListener(handleTabUpdated);
    browser.tabs.onRemoved.addListener(handleTabRemoved);
    browser.runtime.onMessage.addListener(handleMessageReceived);

    // Load day reset time setting
    const settingsData = await browser.storage.local.get('webTimeSettings');
    const settings = settingsData.webTimeSettings || { global: {} };
    dayResetTime = settings.global?.dayResetTime || 0;
    console.log(`Day reset time loaded: ${dayResetTime}:00`);
    
    // Update currentDateStr with the loaded reset time
    currentDateStr = getLocalDateStr();

    await loadTimeData();

    let trackedTabs = await browser.tabs.query({url: ["http://*/*", "https://*/*"]});
    trackedTabs.forEach((tab) => trackedTabIds.add(tab.id));

    let activeTabs = await browser.tabs.query({
        active: true,
        currentWindow: true,
    });
    if (activeTabs.length > 0) {
        activeTabId = activeTabs[0].id;
        updateTimingState(activeTabId);
    }

    setInterval(() => {
        if (activeTabId) {
            updateTimingState(activeTabId);
        }
    }, ACTIVITY_CHECK_INTERVAL_MS);
    console.log("Initialization complete.");
}
init();
