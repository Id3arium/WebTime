const ChartBuilder = {
  getGridColor() {
    return getComputedStyle(document.documentElement)
      .getPropertyValue('--dark-bg').trim();
  },

  createMovingAverageDataset(movingAverageData, label = 'Average') {
    return {
      type: 'line',
      label: label,
      data: movingAverageData.map(day => day.averageHours),
      formattedTimes: movingAverageData.map(day => day.formattedTime),
      backgroundColor: COLORS.movingAverage.background,
      borderColor: COLORS.movingAverage.border,
      borderWidth: COLORS.movingAverage.width,
      fill: false,
      tension: 0.2,
      pointRadius: 3,
      order: -1
    };
  },

  createRankBasedDatasets(dailyData) {
    const numRanks = CONFIG.topDomainsLimit + 1; // 7 ranks + Others
    const datasets = [];
    
    // Create one dataset per rank position
    // Reverse order so Rank 1 (biggest) is at bottom
    for (let rankIndex = numRanks - 1; rankIndex >= 0; rankIndex--) {
      const isOthers = rankIndex === CONFIG.topDomainsLimit;
      const color = isOthers ? COLORS.others : COLORS.domains[rankIndex % COLORS.domains.length];
      const borderColor = color.replace('0.7', '1').replace('0.6', '0.8');
      
      const dataset = {
        type: 'bar',
        label: isOthers ? 'Others' : `Rank ${rankIndex + 1}`,
        data: [],
        domainNames: [], // Store which domain is in this position each day
        backgroundColor: [],
        borderColor: [],
        borderWidth: [],
        order: rankIndex // Lower rank number = drawn first (at bottom)
      };
      
      // Fill data for each day
      dailyData.forEach(dayData => {
        const rankData = dayData.ranks[rankIndex];
        dataset.data.push(rankData ? rankData.hours : 0);
        dataset.domainNames.push(rankData ? rankData.domain : null);
        dataset.backgroundColor.push(color);
        dataset.borderColor.push(borderColor);
        dataset.borderWidth.push(1);
      });
      
      datasets.push(dataset);
    }
    
    return datasets;
  },

  createSingleDomainDataset(dailyData, label = 'This Day') {
    return {
      type: 'bar',
      label: label,
      data: dailyData.map(day => day.domainHours),
      backgroundColor: COLORS.currentDomain.background,
      borderColor: COLORS.currentDomain.border,
      borderWidth: 1,
      formattedTimes: dailyData.map(day => day.domainFormattedTime),
      order: 1
    };
  },

  getBaseChartOptions() {
    return {
      animation: { duration: CONFIG.initAnimationDuration },
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          grid: { color: this.getGridColor() },
          beginAtZero: true,
          ticks: {
            color: '#aaa',
            font: {
              size: 11,
              weight: '500'
            }
          },
          title: { 
            display: true, 
            text: 'Hours',
            color: '#ccc',
            font: {
              size: 12,
              weight: '600'
            }
          }
        },
        x: {
          ticks: {
            color: '#888',
            font: {
              size: 10
            }
          }
        }
      },
      interaction: { intersect: false, mode: 'index' },
      elements: {
        bar: { barPercentage: 0.8, categoryPercentage: 0.9 }
      }
    };
  },

  buildGeneralViewChart(totalTimeData) {
    const datasets = [];
    
    if (totalTimeData.movingAverageData) {
      const avgDataset = this.createMovingAverageDataset(
        totalTimeData.movingAverageData, 
        `${CONFIG.movingAverageDays}-Day Average`
      );
      datasets.push(avgDataset);
    }
    
    const rankDatasets = this.createRankBasedDatasets(totalTimeData.dailyData);
    datasets.push(...rankDatasets);
    
    const totalDays = totalTimeData.dailyData.length;
    const windowSize = CONFIG.daysToDisplay;
    
    // Calculate initial viewport - show most recent days
    const maxIndex = totalDays - 1;
    const minIndex = Math.max(0, totalDays - windowSize);
    
    // Calculate y-axis max with 2 SD cap (95% of data)
    const allTotalHours = totalTimeData.dailyData.map(day => day.totalHours);
    const mean = allTotalHours.reduce((sum, val) => sum + val, 0) / allTotalHours.length;
    const variance = allTotalHours.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / allTotalHours.length;
    const stdDev = Math.sqrt(variance);
    const cappedMax = mean + (2 * stdDev);
    const yAxisMax = Math.ceil(cappedMax);
    
    // Store yAxisMax for tooltip
    totalTimeData._yAxisMax = yAxisMax;
    
    const options = {
      ...this.getBaseChartOptions(),
      scales: {
        ...this.getBaseChartOptions().scales,
        x: { 
          stacked: true,
          min: minIndex,
          max: maxIndex,
          display: true
        },
        y: { 
          ...this.getBaseChartOptions().scales.y, 
          stacked: true,
          max: yAxisMax // Lock y-axis to global max
        }
      },
      plugins: {
        legend: { display: false },
        tooltip: this.getGeneralViewTooltipConfig(totalTimeData)
      },
      onHover: (event, elements, chart) => {
        if (elements.length > 0) {
          const dataIndex = elements[0].index;
          
          // Always update breakdown on hover
          UIManager.updateDailyBreakdown(chart.totalTimeData, dataIndex);
          
          // Always show hover preview (even when locked)
          ChartBuilder.showHoverPreview(chart, dataIndex);
        } else {
          // No elements detected - treat as "left bars area" even if still on canvas
          if (AppState.isLocked()) {
            // Return to locked day
            ChartBuilder.highlightBar(chart, AppState.lockedDayIndex);
            UIManager.updateDailyBreakdown(chart.totalTimeData, AppState.lockedDayIndex);
          } else {
            // Return to today if not locked
            const todayIndex = chart.totalTimeData.dailyData.length - 1;
            ChartBuilder.highlightBar(chart, todayIndex);
            UIManager.updateDailyBreakdown(chart.totalTimeData, todayIndex);
          }
        }
      },
      onClick: (event, elements, chart) => {
        if (elements.length > 0) {
          const clickedIndex = elements[0].index;
          
          if (AppState.lockedDayIndex === clickedIndex) {
            // Clicking the same day unlocks it
            AppState.unlockDay();
            ChartBuilder.removeBarHighlight(chart);
          } else {
            // Lock to new day
            AppState.lockDay(clickedIndex);
            UIManager.updateDailyBreakdown(chart.totalTimeData, clickedIndex);
            ChartBuilder.highlightBar(chart, clickedIndex);
          }
        } else {
          // Clicked empty area - unlock
          AppState.unlockDay();
          ChartBuilder.removeBarHighlight(chart);
        }
      }
    };
    
    return {
      type: 'bar',
      data: {
        labels: totalTimeData.dailyData.map(day => PopUpUtils.formatDateForDisplay(day.date)),
        datasets: datasets
      },
      options: options
    };
  },

  buildDetailViewChart(processedData) {
    const datasets = [];
    
    if (processedData.movingAverageData) {
      const avgDataset = this.createMovingAverageDataset(
        processedData.movingAverageData,
        `${CONFIG.movingAverageDays}-Day Average`
      );
      datasets.push(avgDataset);
    }
    
    const domainDataset = this.createSingleDomainDataset(processedData.dailyData);
    datasets.push(domainDataset);
    
    const totalDays = processedData.dailyData.length;
    const windowSize = CONFIG.daysToDisplay;
    
    // Calculate initial viewport - show most recent days
    const maxIndex = totalDays - 1;
    const minIndex = Math.max(0, totalDays - windowSize);
    
    // Calculate y-axis max with 2 SD cap (95% of data)
    const allDomainHours = processedData.dailyData.map(day => day.domainHours);
    const mean = allDomainHours.reduce((sum, val) => sum + val, 0) / allDomainHours.length;
    const variance = allDomainHours.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / allDomainHours.length;
    const stdDev = Math.sqrt(variance);
    const cappedMax = mean + (2 * stdDev);
    const yAxisMax = Math.ceil(cappedMax);
    
    // Store yAxisMax for tooltip
    processedData._yAxisMax = yAxisMax;
    
    const options = {
      ...this.getBaseChartOptions(),
      scales: {
        ...this.getBaseChartOptions().scales,
        x: { 
          min: minIndex,
          max: maxIndex,
          display: true
        },
        y: {
          ...this.getBaseChartOptions().scales.y,
          max: yAxisMax // Lock y-axis to global max
        }
      },
      plugins: { tooltip: this.getDetailViewTooltipConfig(processedData) }
    };
    
    return {
      type: 'bar',
      data: {
        labels: processedData.dailyData.map(day => PopUpUtils.formatDateForDisplay(day.date)),
        datasets: datasets
      },
      options: options
    };
  },

  getGeneralViewTooltipConfig(totalTimeData) {
    return {
      animation: { duration: 200 },
      backgroundColor: COLORS.tooltipBackground,
      callbacks: {
        title: (context) => {
          const dateString = totalTimeData.dailyData[context[0].dataIndex].date;
          return PopUpUtils.formatDateWithDayOfWeek(dateString);
        },
        label: (context) => {
          const dataIndex = context.dataIndex;
          const dataset = context.dataset;
          
          // Only show average line
          if (dataset.label && dataset.label.includes('Average')) {
            const time = dataset.formattedTimes[dataIndex];
            return `${dataset.label}: ${time}`;
          }
          
          return null;
        },
        afterLabel: (context) => {
          // Show total on first dataset only
          if (context.datasetIndex === 0) {
            const dataIndex = context.dataIndex;
            const dayData = totalTimeData.dailyData[dataIndex];
            const actualHours = dayData.totalHours;
            const yMax = totalTimeData._yAxisMax;
            
            if (actualHours > yMax) {
              const actualTime = PopUpUtils.formatTime(actualHours * 3600);
              const cappedTime = PopUpUtils.formatTime(yMax * 3600);
              return `Total: ${actualTime} (capped at ${cappedTime} for scale)`;
            }
            return `Total: ${dayData.formattedTime}`;
          }
          return null;
        }
      }
    };
  },
  
  highlightBar(chart, barIndex) {
    // Add visual highlight to the clicked bar
    chart.data.datasets.forEach((dataset, datasetIndex) => {
      if (dataset.type === 'bar') {
        // Store original colors if not already stored
        if (!dataset._originalBackgroundColor) {
          dataset._originalBackgroundColor = [...dataset.backgroundColor];
          dataset._originalBorderColor = [...dataset.borderColor];
          dataset._originalBorderWidth = [...dataset.borderWidth];
        }
        
        // Reset all bars to original colors first
        dataset.backgroundColor = [...dataset._originalBackgroundColor];
        dataset.borderColor = [...dataset._originalBorderColor];
        dataset.borderWidth = [...dataset._originalBorderWidth];
        
        // Highlight the selected bar
        if (Array.isArray(dataset.borderColor)) {
          dataset.borderColor[barIndex] = 'white'; // White border
          dataset.borderWidth[barIndex] = 1;
        }
      }
    });
    
    chart.update('none'); // Update without animation
  },
  
  removeBarHighlight(chart) {
    // Remove highlight from all bars
    chart.data.datasets.forEach((dataset) => {
      if (dataset.type === 'bar' && dataset._originalBackgroundColor) {
        dataset.backgroundColor = [...dataset._originalBackgroundColor];
        dataset.borderColor = [...dataset._originalBorderColor];
        dataset.borderWidth = [...dataset._originalBorderWidth];
      }
    });
    
    chart.update('none'); // Update without animation
  },
  
  showHoverPreview(chart, barIndex) {
    // Temporarily highlight the hovered bar while preserving locked state
    chart.data.datasets.forEach((dataset) => {
      if (dataset.type === 'bar') {
        // Store original colors if not already stored
        if (!dataset._originalBackgroundColor) {
          dataset._originalBackgroundColor = [...dataset.backgroundColor];
          dataset._originalBorderColor = [...dataset.borderColor];
          dataset._originalBorderWidth = [...dataset.borderWidth];
        }
        
        // Reset all bars to original colors first
        dataset.backgroundColor = [...dataset._originalBackgroundColor];
        dataset.borderColor = [...dataset._originalBorderColor];
        dataset.borderWidth = [...dataset._originalBorderWidth];
        
        // Restore locked highlight if there is one
        if (AppState.isLocked() && Array.isArray(dataset.borderColor)) {
          dataset.borderColor[AppState.lockedDayIndex] = 'white'; // Solid white for locked
          dataset.borderWidth[AppState.lockedDayIndex] = 1;
        }
        
        // Show preview highlight (only if different from locked bar)
        if (Array.isArray(dataset.borderColor) && barIndex !== AppState.lockedDayIndex) {
          dataset.borderColor[barIndex] = 'rgba(255, 255, 255, 0.8)'; // Semi-transparent white for preview
          dataset.borderWidth[barIndex] = 1;
        }
      }
    });
    
    chart.update('none'); // Update without animation
  },

  getDetailViewTooltipConfig(processedData) {
    return {
      animation: { duration: 200 },
      backgroundColor: COLORS.tooltipBackground,
      callbacks: {
        title: (context) => {
          const dateString = processedData.dailyData[context[0].dataIndex].date;
          return PopUpUtils.formatDateWithDayOfWeek(dateString);
        },
        label: (context) => {
          const dataset = context.chart.data.datasets[context.datasetIndex];
          const dataIndex = context.dataIndex;
          const dayData = processedData.dailyData[dataIndex];
          const time = dataset.formattedTimes[dataIndex];
          
          // Check if this bar is capped
          if (dataset.type === 'bar' && dayData.domainHours > processedData._yAxisMax) {
            const actualTime = dayData.domainFormattedTime;
            const cappedTime = PopUpUtils.formatTime(processedData._yAxisMax * 3600);
            return `${dataset.label}: ${actualTime} (capped at ${cappedTime} for scale)`;
          }
          
          return `${dataset.label}: ${time}`;
        }
      }
    };
  }
};
