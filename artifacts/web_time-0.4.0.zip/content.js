// This script creates a timer element and appends it to the body of the webpage.
// It also provides functions to update the timer text and manage the timer state.

let timerText = null;
let lastActivityTime = Date.now();

function createTimerElement() {
    console.log('[WebTime Debug Content] Creating timer element...');
    const timer = document.createElement("div");
    timer.className = "web-time-timer";

    timerText = document.createElement("div");
    timerText.className = "web-time-timer-text";
    timerText.textContent = "00:00:00";

    timer.appendChild(timerText);
    document.body.appendChild(timer);

    console.log('[WebTime Debug Content] Timer element created and added to page. Element:', timer);
    
    // Check if element is visible
    const rect = timer.getBoundingClientRect();
    const styles = window.getComputedStyle(timer);
    console.log('[WebTime Debug Content] Timer position:', rect);
    console.log('[WebTime Debug Content] Timer visibility:', styles.visibility);
    console.log('[WebTime Debug Content] Timer display:', styles.display);
    console.log('[WebTime Debug Content] Timer z-index:', styles.zIndex);
}

function handleIncomingMessage(message, sender, sendResponse) {
    console.log('[WebTime Debug Content] Received message:', message);
    if (message.type === "TIME_UPDATE") {
        if (timerText) {
            timerText.textContent = Utils.formatTimeWithSeconds(message.time);
            console.log('[WebTime Debug Content] Updated timer text to:', timerText.textContent);
        } else {
            console.error('[WebTime Debug Content] Timer text element not found when trying to update time!');
        }
    }
}

function updateActivityState() {
    lastActivityTime = Date.now();
    browser.runtime.sendMessage({ type: "USER_ACTIVE" });
}

// Set up event listeners for user activity
document.addEventListener("scroll", updateActivityState);
document.addEventListener("keydown", updateActivityState);
document.addEventListener("mousemove", updateActivityState);

function init() {
    console.log('[WebTime Debug Content] initTimer() called');

    // Wait a moment for the page to be ready
    if (document.body) {
        createTimerElement();
    } else {
        console.log('[WebTime Debug Content] Body not ready, waiting...');
        document.addEventListener('DOMContentLoaded', createTimerElement);
    }
    
    browser.runtime.onMessage.addListener(handleIncomingMessage);

    try {
        const readyMessage = { type: "CONTENT_SCRIPT_READY" };
        browser.runtime.sendMessage(readyMessage);
        console.log('[WebTime Debug Content] Sent CONTENT_SCRIPT_READY message to background.');
    } catch (error) {
        console.error('[WebTime Debug Content] Error sending CONTENT_SCRIPT_READY message:', error);
    }
}

init();
